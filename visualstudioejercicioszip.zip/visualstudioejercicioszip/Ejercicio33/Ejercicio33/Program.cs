﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio33
{
    internal class Program
    {
        static void Main(string[] args)
        {
			// Entrada
			Console.Write("Ingrese el radio: ");
			double r = double.Parse(Console.ReadLine());

			// Proceso
			double area = Math.PI * Math.Pow(r, 2);
			double perimetro = 2 * Math.PI * r;

			// Salida
			Console.WriteLine("Área: " + area);
			Console.WriteLine("Perímetro: " + perimetro);

			Console.ReadKey();
		}
    }
}
