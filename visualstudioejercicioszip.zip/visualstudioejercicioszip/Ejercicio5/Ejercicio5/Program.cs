﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio5
{
    internal class Program
    {
        static void Main(string[] args)
        {
			// Entrada
			Console.Write("Ingrese un precio: ");
			double precio = double.Parse(Console.ReadLine());

			// Proceso
			double arriba = Math.Ceiling(precio);
			double abajo = Math.Floor(precio);
			double truncado = Math.Truncate(precio);

			// Salida
			Console.WriteLine("Ceiling (arriba): " + arriba);
			Console.WriteLine("Floor (abajo): " + abajo);
			Console.WriteLine("Truncado: " + truncado);

			Console.ReadKey();
		}
    }
}
