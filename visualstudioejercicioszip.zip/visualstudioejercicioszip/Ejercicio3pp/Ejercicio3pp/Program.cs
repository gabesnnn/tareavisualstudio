﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio3pp
{
    internal class Program
    {
        static void Main(string[] args)
        {
			Console.Write("Ingrese la temperatura en Celsius: ");
			double celsius = Convert.ToDouble(Console.ReadLine());

			double fahrenheit = (celsius * 9.0 / 5.0) + 32;
			double kelvin = celsius + 273.15;

			Console.WriteLine("Temperatura en Fahrenheit: " + fahrenheit);
			Console.WriteLine("Temperatura en Kelvin: " + kelvin);

			Console.ReadLine();
		}
    }
}
