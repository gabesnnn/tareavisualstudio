﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio1p
{
    internal class Program
    {
        static void Main(string[] args)
        {
			// Entrada
			Console.Write("Ingrese cantidad de habitaciones: ");
			int habitaciones = int.Parse(Console.ReadLine());

			Console.Write("Ingrese cantidad de baños: ");
			int baños = int.Parse(Console.ReadLine());

			Console.Write("Ingrese cantidad de patios: ");
			int patios = int.Parse(Console.ReadLine());

			// Proceso
			double total = (habitaciones * 30) + (baños * 10) + (patios * 15);

			// Salida
			Console.WriteLine("Total mensual: S/." + total);

			Console.ReadKey();
		}
    }
}
