﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio2p
{
    internal class Program
    {
        static void Main(string[] args)
        {
			// Entrada
			Console.Write("Ingrese kWh consumidos: ");
			double kwh = double.Parse(Console.ReadLine());

			// Proceso
			double subtotal = 5.00 + (kwh * 0.55);
			double igv = subtotal * 0.18;
			double total = subtotal + igv;

			// Salida
			Console.WriteLine("Subtotal: S/." + subtotal);
			Console.WriteLine("IGV: S/." + igv);
			Console.WriteLine("Total: S/." + total);

			Console.ReadKey();
		}
    }
}
